<?php
// Admin Login Details
$user_admin = "anuj"; 
$pass_admin = "anuj786";

if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== $user_admin || $_SERVER['PHP_AUTH_PW'] !== $pass_admin) {
    header('WWW-Authenticate: Basic realm="ANUJ KASHYAP ADMIN"');
    header('HTTP/1.0 401 Unauthorized');
    die("<h1 style='color:red; text-align:center;'>Abe Admin Nahi Hai Tu! 😂</h1>");
}

$conn = mysqli_connect("localhost", "root", "", "kingfish_db", 3306, "/data/data/com.termux/files/usr/var/run/mysqld.sock");

// HWID Reset Logic
if(isset($_GET['reset'])){
    $id = (int)$_GET['reset'];
    mysqli_query($conn, "UPDATE keys_list SET hwid=NULL WHERE id=$id");
    header("location:admin.php");
}

// Delete Key Logic
if(isset($_GET['delete'])){
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM keys_list WHERE id=$id");
    header("location:admin.php");
}

$result = mysqli_query($conn, "SELECT * FROM keys_list ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN PANEL | ANUJ KASHYAP</title>
    <style>
        body { background: #050505; color: #00ff00; font-family: 'Segoe UI', sans-serif; text-align: center; padding: 10px; }
        .header { background: #111; padding: 20px; border-bottom: 3px solid #00ff00; margin-bottom: 20px; box-shadow: 0 5px 15px rgba(0,255,0,0.2); }
        h1 { margin: 0; letter-spacing: 2px; text-shadow: 0 0 10px #00ff00; }
        .table-container { overflow-x: auto; background: #111; border-radius: 10px; padding: 10px; border: 1px solid #333; }
        table { width: 100%; border-collapse: collapse; min-width: 600px; }
        th, td { padding: 12px; border: 1px solid #222; text-align: center; font-size: 14px; }
        th { background: #00ff00; color: #000; text-transform: uppercase; }
        tr:nth-child(even) { background: #1a1a1a; }
        .btn { padding: 6px 12px; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 12px; display: inline-block; margin: 2px; }
        .btn-reset { background: #ffaa00; color: black; }
        .btn-del { background: #ff3333; color: white; }
        .status-active { color: #00ff00; font-weight: bold; }
        .status-used { color: #888; }
    </style>
</head>
<body>

    <div class="header">
        <h1>ANUJ KASHYAP ADMIN PANEL 🥳</h1>
        <p style="color: #888;">Manage Your VIP Keys & Devices</p>
    </div>

    <div class="table-container">
        <table>
            <tr>
                <th>ID</th>
                <th>VIP KEY</th>
                <th>EXPIRY DATE</th>
                <th>DEVICE</th>
                <th>LIMIT</th>
                <th>ACTIONS</th>
            </tr>
            <?php while($row = mysqli_fetch_assoc($result)) { 
                $hwid_status = empty($row['hwid']) ? "<span class='status-active'>Not Used</span>" : "<span class='status-used'>Locked</span>";
            ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td style="color: #fff; font-weight: bold;"><?php echo $row['license_key']; ?></td>
                <td><?php echo $row['expiry_date']; ?></td>
                <td><?php echo $hwid_status; ?></td>
                <td><?php echo $row['dev_limit']; ?></td>
                <td>
                    <a href="admin.php?reset=<?php echo $row['id']; ?>" class="btn btn-reset" onclick="return confirm('Reset Device HWID?')">RESET</a>
                    <a href="admin.php?delete=<?php echo $row['id']; ?>" class="btn btn-del" onclick="return confirm('Delete this key?')">DEL</a>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>

    <div style="margin-top: 20px;">
        <a href="generate.php" style="color: #00ff00; text-decoration: none;">+ Generate New Key</a>
    </div>

</body>
</html>