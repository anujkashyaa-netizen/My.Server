<?php
// डेटाबेस कनेक्शन (Socket Path के साथ)
$conn = mysqli_connect("localhost", "root", "", "kingfish_db", 3306, "/data/data/com.termux/files/usr/var/run/mysqld.sock");

if (!$conn) {
    die("Database Connection Failed!");
}

echo "<h2>VIP Key Status Checker</h2>";
echo '<form method="GET">
        <input type="text" name="key" placeholder="Enter VIP Key" required>
        <button type="submit">Check Status</button>
      </form>';

if (isset($_GET['key'])) {
    $userKey = mysqli_real_escape_string($conn, $_GET['key']);
    
    // डेटाबेस में Key ढूंढें
    $query = "SELECT * FROM keys_list WHERE license_key = '$userKey'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo "<br><b style='color:green;'>✅ VIP Activated!</b><br>";
        echo "Key: " . $row['license_key'] . "<br>";
        echo "Status: Active";
    } else {
        echo "<br><b style='color:red;'>❌ Invalid Key or Expired!</b>";
    }
}

mysqli_close($conn);
?>