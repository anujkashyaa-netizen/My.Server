<?php
error_reporting(0);
$conn = mysqli_connect("localhost", "root", "", "kingfish_db", 3306, "/data/data/com.termux/files/usr/var/run/mysqld.sock");

$msg = "";

if(isset($_POST['generate'])){
    $key = "VIP-" . strtoupper(bin2hex(random_bytes(4)));
    $days = (int)$_POST['days'];
    $dev_limit = (int)$_POST['dev_limit'];
    $expiry_date = date('Y-m-d H:i:s', strtotime("+$days days"));

    $sql = "INSERT INTO keys_list (license_key, expiry_date, dev_limit, status) VALUES ('$key', '$expiry_date', '$dev_limit', 'active')";
    
    if(mysqli_query($conn, $sql)){
        $msg = "<div style='background: #004d00; border: 1px solid #00ff00; padding: 10px; margin-bottom: 20px; color: #00ff00;'>
                <b>SUCCESS! KEY GENERATED</b><br>
                Key: <span style='color:white;'>$key</span><br>
                Limit: $dev_limit Device<br>
                Expiry: $expiry_date </div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ANUJ KASHYAP VIP GEN</title>
    <style>
        body { background: #0a0a0a; color: #00ff00; font-family: monospace; text-align: center; padding: 20px; }
        .container { background: #151515; border: 2px solid #00ff00; border-radius: 15px; padding: 25px; display: inline-block; width: 100%; max-width: 350px; box-shadow: 0 0 15px #00ff00; }
        select, button { width: 100%; padding: 12px; margin: 10px 0; border-radius: 5px; border: 1px solid #00ff00; background: #222; color: #00ff00; font-weight: bold; }
        button { background: #00ff00; color: #000; cursor: pointer; text-transform: uppercase; }
        h2 { color: #00ff00; text-shadow: 0 0 10px #00ff00; font-size: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>VIP PANEL ANUJ KASHYAP 🥳</h2>
        
        <?php echo $msg; ?>
        <form method="POST">
            <label>VALIDITY:</label>
            <select name="days">
                <option value="1">1 DAY</option>
                <option value="7">7 DAYS</option>
                <option value="30">30 DAYS</option>
            </select>

            <label>DEVICE LIMIT:</label>
            <select name="dev_limit">
                <option value="1">1 DEVICE</option>
                <option value="2">2 DEVICES</option>
            </select>

            <button type="submit" name="generate">GENERATE KEY</button>
        </form>
    </div>
</body>
</html>