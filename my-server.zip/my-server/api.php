<?php
// डेटाबेस की जानकारी (अपनी सही वाली डालें)
$host = "localhost";
$host = "127.0.0.1"; // localhost की जगह यह डालो
$user = "root";
$pass = ""; 
$db   = "kingfish_db"; // यहाँ वो नाम डालना जो ऊपर स्टेप 1 में दिखा था

$conn = mysqli_connect($host, $user, $pass, $db);
// अगर कनेक्शन फेल हो जाए
if (!$conn) {
    die(json_encode(["status" => false, "msg" => "Database Connection Failed"]));
}

// डेटा चेक करना (Error रोकने के लिए)
$key  = isset($_POST['key']) ? $_POST['key'] : null;
$hwid = isset($_POST['hwid']) ? $_POST['hwid'] : null;

if (!$key || !$hwid) {
    echo json_encode(["status" => false, "msg" => "Key or HWID missing"]);
    exit();
}

// डेटाबेस में चेक करना
$sql = "SELECT * FROM keys_list WHERE license_key = '$key'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    echo json_encode([
        "status" => true,
        "data" => [
            "token" => bin2hex(random_bytes(16)),
            "EXP" => $row['expiry_date']
        ]
    ]);
} else {
    echo json_encode(["status" => false, "msg" => "Invalid License Key"]);
}

mysqli_close($conn);
?>